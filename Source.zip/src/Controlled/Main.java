package Controlled;

import java.awt.AWTException;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.BindException;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 *
 * @author Ctr1
 */
public class Main extends javax.swing.JFrame {

    //protected String verification = "099$$verification"; //验证部分
    private ArrayList<PrintWriter> clientOutputStreams;
    ControlThread cont; //键盘鼠标Class
    CaptureThread capt; //图像传输Class
    boolean pausestate = false;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  //日期格式
    String stime = sdf.format(System.currentTimeMillis()); //取启动时间(用作记录日志)
    ServerSocket serverSocket;
    String clientIP; //连接者的IP
    int dport; //连接者端的socket文件服务器
    int connectnum = 0;
    Socket cli; //语音Socket.accept
    SoundServer s;
    SoundClient c;

    public class FileServer {

        public static final int PORT = 12930; //download端口
        int port;

        FileServer() {
            System.out.println("文件上传端口：" + port);
        }

        public void start() {
            System.out.println("start...");
            String dpath = null;
            try ( //创建服务器端对象
                    ServerSocket server = new ServerSocket(PORT);) { //备用口
                while (true) {

                    Socket socket = server.accept();
                    if (!onlywatch) {
                        int option = JOptionPane.showConfirmDialog(Main.this, "接收到文件，是否同意接收？", "提示", JOptionPane.YES_OPTION); //Main.this 设定父窗口
                        if (option == JOptionPane.YES_OPTION) {
                            JFileChooser Chooser = new JFileChooser();
                            Chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                            int approve = Chooser.showDialog(Main.this, "选择目录");
                            if (approve == JFileChooser.APPROVE_OPTION) {        //判断是否点击了确定。如果是取消则无操作
                                File dselectedFile = Chooser.getSelectedFile();

                                dpath = dselectedFile.getAbsolutePath(); //目标保存目录
                                String filename;
                                if (!dpath.equals("")) {
                                    try ( //创建文件输出流和网络输入流
                                            DataInputStream in = new DataInputStream(socket.getInputStream());
                                            //读取发来的文件名**，创建文件输出流

                                            FileOutputStream out = new FileOutputStream(dpath + "\\" + in.readUTF())) { // FileOutputStream out = new FileOutputStream(dpath + in.readUTF())) {
                                        int len = 0;
                                        byte[] buffer = new byte[1024];
                                        while ((len = in.read(buffer)) != -1) {
                                            out.write(buffer, 0, len);
                                        }
                                        jtshow.append("文件已经保存到 " + dpath + "。\n");
                                        new Info().Log("一个文件在" + sdf.format(System.currentTimeMillis()) + " 被保存至" + dpath, stime, "op"); //日志记录
                                        System.out.println("服务器保存完毕！");
                                    }
                                }
                            }
                        } else {
                            //点了否，无操作
                            new Info().Log("在" + sdf.format(System.currentTimeMillis()) + " 拒绝了一次文件上传请求。", stime, "op"); //日志记录
                        }
                    }
                }
            } catch (BindException e) {
                try {
                    //                jbupload.setEnabled(false); //禁用上传文件
//                jbupload.setToolTipText("无法启动文件上传端口");
                    new Info().Log(sdf.format(System.currentTimeMillis()) + " ：无法启动文件上传端口。[" + e.toString() + "]", stime, "op"); //日志记录
                } catch (IOException ex) {
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Creates new form Main
     */
    public Main() {
        initComponents(); //加载页面组件
        init(); //初始化
        System.out.println(stime); //启动时间
    }

    boolean connectstate = false; //连接状态
    DatagramSocket voicesocket = null;

    public void init() {
        bottomstate(connectstate);

        // 建立端口
        ActionListener startListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clientOutputStreams = new ArrayList<PrintWriter>();
                String aPort = port.getText();
                if (aPort.equals("")) {
                    jtshow.append("端口号不合法！\n");
                } else {
                    try {
                        // 等待客户端连接的线程
                        Runnable serverRunnable = new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    serverSocket = new ServerSocket(Integer.parseInt(aPort));
                                    try {
                                        new Info().Log("受控端于" + sdf.format(System.currentTimeMillis()) + " 启动了端口号: " + aPort + "。", stime, "op"); //日志记录
                                    } catch (IOException ex) {
                                    }
                                    // serverSocket.setSoTimeout(5000); //Socket超时事件
                                    port.setEnabled(false);
                                    jbport.setText("受控端口号: " + port.getText());
                                    port.setText("连接数: " + connectnum);
                                    jbport.setEnabled(false);
                                    jtshow.setText("");
                                    jtshow.append("受控端已启动...\n");
                                    Thread tc = new Thread(new Runnable() {
                                        public void run() {
                                            // run方法具体重写
                                            new FileServer().start();
                                        }
                                    });
                                    tc.start(); //文件启动

                                    while (true) {
                                        Socket clientSocket = serverSocket.accept();
                                        Socket controlSocket = serverSocket.accept(); //必须单独创建一个堵塞通道！

                                        //jtshow.setText("");
                                        jtshow.append("控制端已连接...\n");

                                        connectnum++;
                                        port.setText("连接数: " + connectnum);

                                        try {
                                            new Info().Log("控制端 " + clientSocket.getLocalAddress().getHostAddress() + " 于" + sdf.format(System.currentTimeMillis()) + " 连接至控制端口。", stime, "op"); //日志记录
                                        } catch (IOException ex) {
                                        }
                                        bottomstate(!connectstate); //按钮解锁
                                        jtsend.setEnabled(true);

                                        //////////////////////////////////////////////////////////////////////////////
                                        try {
                                            ObjectInputStream ois = new ObjectInputStream(controlSocket.getInputStream());
                                            OutputStream oss = controlSocket.getOutputStream();
                                            DataOutputStream dos = new DataOutputStream(oss);
                                            cont = new ControlThread(ois, stime); //鼠标控制类 传stime（记录日志）
                                            cont.start();//���������߳�
                                            capt = new CaptureThread(dos);//图像传输类
                                            capt.start();
                                            System.out.println("启动屏幕图像传输。"); //FLAGS
                                        } catch (IOException e) {
                                            // TODO Auto-generated catch block
                                            e.printStackTrace();
                                        }
                                        //////////////////////////////////////////////////////////////////////////////

                                        PrintWriter writer = new PrintWriter(new OutputStreamWriter(clientSocket.getOutputStream(), "UTF-8"), true);
                                        clientOutputStreams.add(writer);

                                        Thread t = new Thread(new ClientHandler(clientSocket));
                                        t.start();

                                        cont.k(checkkey.isSelected());
                                        cont.m(checkmouse.isSelected());

                                    }
                                } catch (NumberFormatException e) {
                                    jtshow.append("端口配置错误...可能是端口号不合法或端口不可用。\n");
                                    return;
                                    // e.printStackTrace();
                                } catch (IOException e) {
                                }
                            }
                        };
                        Thread serverThread = new Thread(serverRunnable); //收消息
                        serverThread.start();

                    } catch (Exception ex) {
                        jtshow.append("意外情况。\n");
                        ex.printStackTrace();
                    }
                }
            }
        };

        jbport.addActionListener(startListener);
        port.addActionListener(startListener);

        // 监听Say按钮，发送消息
        ActionListener SayListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String aText = jtsend.getText();
                if (!aText.equals("")) {
                    aText = "受控端 | " + aText;
                    sendToEveryClient(aText);
                    jtshow.append(aText + "\n");
                    jtsend.setText("");
                    try {
                        new Info().Log(sdf.format(System.currentTimeMillis()) + " " + aText, stime, "chat"); //日志记录
                    } catch (IOException ex) {
                    }
                } else {
                    //    JOptionPane.showMessageDialog(serverFrame, "内容不能为空！");
                }
            }
        };

        jbsend.addActionListener(SayListener);
        jtsend.addActionListener(SayListener);

    }

    // 多客户端的线程
    public class ClientHandler implements Runnable {

        BufferedReader bReader;
        Socket aSocket;

        public ClientHandler(Socket clientSocket) {
            try {
                aSocket = clientSocket;
                bReader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream(), "UTF-8"));
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        @Override
        public void run() {
            String message;
            try {
                while ((message = bReader.readLine()) != null) {

                    if (isKeyEventText(message)) { //判断键盘事件（测试）
                        //键盘事件
                    } else {
                        if (message.equals("EndVoice!")) {
                            try {
                                new Info().Log("受控端于" + sdf.format(System.currentTimeMillis()) + " 结束语音通话。", stime, "op"); //日志记录
                            } catch (IOException ex) {
                            }
                            voice.setEnabled(false);
                        } else if (message.equals("VoiceChat!!!!!!")) {
                            if (!onlywatch) {//投屏模式
                                int option = JOptionPane.showConfirmDialog(Main.this, "收到语音请求，是否同意？", "提示", JOptionPane.YES_OPTION); //Main.this 设定父窗口
                                if (option == JOptionPane.YES_OPTION) {
                                    Thread tc = new Thread(new Runnable() {

                                        public void run() {
                                            try {
                                                System.out.println("创建语音通道。");
                                                sendToEveryClient("VoicechatPositive");
                                                try {
                                                    new Info().Log("受控端于" + sdf.format(System.currentTimeMillis()) + " 启动语音通话。", stime, "op"); //日志记录
                                                } catch (IOException ex) {
                                                }
                                                voice.setEnabled(true);
//                                            ServerSocket serSock = new ServerSocket(8990); //8990是语音端口
//                                            cli = serSock.accept();
//                                            Playback player = new Playback(cli);
//                                            player.start();

                                                voicesocket = new DatagramSocket(8990);
                                                s = new SoundServer(voicesocket);
                                                c = new SoundClient(8991, clientIP);
                                                c.start();

                                            } catch (Exception ex) {
                                                jtshow.append("语音端口创建失败。端口被占用或无权限。\n");
                                                try {
                                                    new Info().Log("受控端于" + sdf.format(System.currentTimeMillis()) + "建立语音通话失败。", stime, "op"); //日志记录
                                                } catch (IOException e) {
                                                }
                                                voice.setEnabled(false);
                                            }
                                        }
                                    });
                                    tc.start();
                                } else {
                                    sendToEveryClient("受控端拒绝了语音通信请求。");
                                    try {
                                        new Info().Log("受控端于" + sdf.format(System.currentTimeMillis()) + " 绝了语音通信请求。", stime, "op"); //日志记录
                                    } catch (IOException ex) {
                                    }
                                }
                            } else {
                                sendToEveryClient("受控端拒绝了语音通信请求。");
                                try {
                                    new Info().Log("受控端于" + sdf.format(System.currentTimeMillis()) + " 绝了语音通信请求。", stime, "op"); //日志记录
                                } catch (IOException ex) {
                                }
                            }
                        } else if (message.equals("**watcher**@#@#@#@#@#@#@#@#!!!!!")) { //观察者模式
                            cont.k(false);
                            cont.m(false);
                            checkdos.setSelected(false); //关闭dos
                            System.out.println("启动观察者模式");
                            new Info().Log("控制端于 " + sdf.format(System.currentTimeMillis()) + " 进入观察者模式。", stime, "op");
                        } else if (message.length() > 8 && message.substring(0, 8).equalsIgnoreCase("IP|%^^^#")) {
                            //   writer.println("IP|"+new Info().GetLocalIP()+"&"+dport); //本机IP加随机文件传输端口
                            clientIP = message.substring(message.indexOf("#") + 1, message.indexOf("&"));
                            dport = Integer.parseInt(message.substring(message.indexOf("&") + 1, message.length()));
                            try {
                                new Info().Log("一个控制端 " + sdf.format(System.currentTimeMillis()) + " 连接成功。其IP " + clientIP + " 以及开放的文件端口号为：" + dport + "。", stime, "op"); //日志记录
                            } catch (IOException ex) {
                            }
                        } else if (message.length() > 9 && message.substring(0, 9).equalsIgnoreCase("dosEvent!")) {
//                        sendToEveryClient(new CommandTest().exeCmd("ping www.baidu.com"));
                            String comm = message.substring(message.indexOf("!") + 1, message.length());
                            Thread tc = new Thread(new Runnable() {
                                public void run() {
                                    if (checkdos.isSelected() == true && !onlywatch) { //投屏模式条件
                                        try {
                                            //判断是否允许
                                            exeCmd(comm); //线程执行
                                            new Info().Log("控制端于 " + sdf.format(System.currentTimeMillis()) + " 执行了DOS命令操作。[执行命令：" + comm + "]", stime, "op");
                                        } catch (IOException ex) {
                                        }
                                    } else {
                                        try {
                                            sendToEveryClient("没有权限执行DOS命令。");
                                            new Info().Log("拒绝了控制端于 " + sdf.format(System.currentTimeMillis()) + " 请求DOS命令操作。[尝试执行：" + comm + "]", stime, "op");
                                        } catch (IOException ex) {
                                        }
                                    }
                                }
                            });
                            tc.start();
                            System.out.println("DOS事件");
                        } else {
                            System.out.println(message);
                            sendToEveryClient(message);
                            new Info().Log(sdf.format(System.currentTimeMillis()) + " " + message, stime, "chat"); //聊天记录
                            jtshow.append(message + "\n");
                        }
                    }
                }
            } catch (SocketException e) {
                try {
                    bReader.close();
                    aSocket.close();
                    ///调整正在连接的个数
                    connectnum--;
                    port.setText("连接数: " + connectnum);
                    ///////////

                } catch (IOException ex) {
                    Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    //键盘事件操作
    public boolean isKeyEventText(String str) throws AWTException, IOException { //键盘事件处理,在另外Server控制类尝试过writeObject但是会有未序列化的问题,这个方法并不理想。
        Robot myRobot = new Robot();
        int code = 0; //键盘Key

        //java.awt.event.KeyEvent[KEY_RELEASED,keyCode=65,keyText=A,keyChar='a',keyLocation=KEY_LOCATION_STANDARD,rawCode=65,primaryLevelUnicode=97,scancode=30,extendedKeyCode=0x41] on frame0
        if (str.length() > 28 && str.substring(0, 28).equalsIgnoreCase("java.awt.event.KeyEvent[KEY_")) {
            if (checkkey.isSelected()) {   //检查是否允许键盘操作
                if (str.substring(str.indexOf("_") + 1, str.indexOf(",")).equalsIgnoreCase("RELEASED")) {
                    System.out.println("RELEASED");
                    code = Integer.parseInt(str.substring(str.indexOf("=") + 1, str.indexOf(",", str.indexOf(",") + 1)).toString());
                    System.out.println(code);
                    myRobot.keyRelease(code);
                    new Info().Log("控制端在 " + sdf.format(System.currentTimeMillis()) + " 进行了键盘操作。[" + str + "]", stime, "op");
                }

                if (str.substring(str.indexOf("_") + 1, str.indexOf(",")).equalsIgnoreCase("PRESSED")) {
                    System.out.println("PRESSED");
                    code = Integer.parseInt(str.substring(str.indexOf("=") + 1, str.indexOf(",", str.indexOf(",") + 1)));
                    System.out.println(code);
                    myRobot.keyPress(code);
                    new Info().Log("控制端在 " + sdf.format(System.currentTimeMillis()) + " 进行了键盘操作。[" + str + "]", stime, "op");
                }
                if (str.substring(str.indexOf("_") + 1, str.indexOf(",")).equalsIgnoreCase("TYPED")) {
                    System.out.println("TYPED");
                }
            } else {
                new Info().Log("拒绝了控制端于 " + sdf.format(System.currentTimeMillis()) + " 请求的键盘标操作。[" + str + "]", stime, "op");
            }
            return true;
        }

        return false;

    }

    //DOS函数
    public void exeCmd(String commandStr) {

        BufferedReader br = null;
        try {
            Process p = Runtime.getRuntime().exec("cmd /c " + commandStr);
            br = new BufferedReader(new InputStreamReader(p.getInputStream(), Charset.forName("GBK")));
            String line = null;
            StringBuilder sb = new StringBuilder();
            while ((line = br.readLine()) != null) {
                System.out.println(line);
                sendToEveryClient(line);
            }
            System.out.println(sb.toString());

        } catch (Exception e) {
            e.printStackTrace();

        } finally {

            if (br != null) {
                try {
                    br.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    } //执行DOS指令

// 发送消息给所有客户端的方法
    private void sendToEveryClient(String message) {
        Iterator<PrintWriter> it = clientOutputStreams.iterator();
        while (it.hasNext()) {
            try {
                PrintWriter writer = (PrintWriter) it.next();
                writer.println(message);
                writer.flush();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    //按钮状态
    private void bottomstate(boolean state) {
        if (state == false) {
            checkno.setEnabled(false);
            checkdos.setEnabled(false);
            checkkey.setEnabled(false);
            checkmouse.setEnabled(false);
            jbpause.setEnabled(false);
            jbupload.setEnabled(false);
            jLabel_permit.setEnabled(false);
            jbsend.setEnabled(false);
            jtsend.setEnabled(false);
        } else {
            checkno.setEnabled(true);
            checkdos.setEnabled(true);
            checkkey.setEnabled(true);
            checkmouse.setEnabled(true);
            jbpause.setEnabled(true);
            jbupload.setEnabled(true);
            jbonlywatch.setEnabled(true);
            jLabel_permit.setEnabled(true);
            jbsend.setEnabled(true);
            jtsend.setEditable(true);
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jSeparator1 = new javax.swing.JSeparator();
        jButton1 = new javax.swing.JButton();
        jToggleButton1 = new javax.swing.JToggleButton();
        jMenuItem1 = new javax.swing.JMenuItem();
        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();
        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jbsend = new javax.swing.JButton();
        voice = new javax.swing.JButton();
        jbonlywatch = new javax.swing.JButton();
        jbupload = new javax.swing.JButton();
        jbpause = new javax.swing.JButton();
        checkdos = new javax.swing.JCheckBox();
        jLabel_permit = new javax.swing.JLabel();
        checkmouse = new javax.swing.JCheckBox();
        checkkey = new javax.swing.JCheckBox();
        jtsend = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtshow = new javax.swing.JTextArea();
        port = new javax.swing.JTextField();
        jbport = new javax.swing.JButton();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(32767, 32767));
        checkno = new javax.swing.JCheckBox();
        MenuBar = new javax.swing.JMenuBar();
        Menu = new javax.swing.JMenu();
        log = new javax.swing.JMenuItem();
        linkstate = new javax.swing.JMenuItem();
        state = new javax.swing.JMenuItem();
        about = new javax.swing.JMenuItem();

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane.setViewportView(jTextArea1);

        jButton1.setText("jButton1");

        jToggleButton1.setText("jToggleButton1");

        jMenuItem1.setText("jMenuItem1");

        jCheckBoxMenuItem1.setSelected(true);
        jCheckBoxMenuItem1.setText("jCheckBoxMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setAlwaysOnTop(true);
        setLocation(new java.awt.Point(-1, -1));
        setResizable(false);

        jbsend.setText("发送消息");
        jbsend.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbsendActionPerformed(evt);
            }
        });

        voice.setText("结束语音");
        voice.setToolTipText("");
        voice.setEnabled(false);
        voice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voiceActionPerformed(evt);
            }
        });

        jbonlywatch.setText("投屏模式：关");
        jbonlywatch.setToolTipText("将屏蔽所有文件上传请求、禁用键盘鼠标、DOS事件");
        jbonlywatch.setEnabled(false);
        jbonlywatch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbonlywatchActionPerformed(evt);
            }
        });

        jbupload.setText("上传文件");
        jbupload.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbuploadActionPerformed(evt);
            }
        });

        jbpause.setText("暂停连接");
        jbpause.setToolTipText("暂停屏幕传输(1-1)");
        jbpause.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbpauseActionPerformed(evt);
            }
        });

        checkdos.setText("控制端执行DOS命令");
        checkdos.setToolTipText("");
        checkdos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkdosActionPerformed(evt);
            }
        });

        jLabel_permit.setText("允许控制端操作");

        checkmouse.setText("鼠标");
        checkmouse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkmouseActionPerformed(evt);
            }
        });

        checkkey.setText("键盘");
        checkkey.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkkeyActionPerformed(evt);
            }
        });

        jtshow.setEditable(false);
        jtshow.setColumns(20);
        jtshow.setFont(new java.awt.Font("宋体", 0, 15)); // NOI18N
        jtshow.setRows(5);
        jtshow.setText("请先启动控制端口。在下方输入框输入启动的端口号。\n");
        jScrollPane1.setViewportView(jtshow);

        jbport.setText("启动端口");

        checkno.setText("无人监管模式");
        checkno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checknoActionPerformed(evt);
            }
        });

        Menu.setText("信息");

        log.setText("完整日志");
        log.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logActionPerformed(evt);
            }
        });
        Menu.add(log);

        linkstate.setText("连接说明");
        linkstate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                linkstateActionPerformed(evt);
            }
        });
        Menu.add(linkstate);

        state.setText("状态信息");
        state.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stateActionPerformed(evt);
            }
        });
        Menu.add(state);

        about.setText("关于");
        about.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aboutActionPerformed(evt);
            }
        });
        Menu.add(about);

        MenuBar.add(Menu);

        setJMenuBar(MenuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jbsend, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jtsend, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(checkdos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel_permit)
                                    .addComponent(checkno, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(checkkey)
                                    .addComponent(checkmouse))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 19, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(port, javax.swing.GroupLayout.DEFAULT_SIZE, 128, Short.MAX_VALUE)
                                .addComponent(jbupload, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(voice, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jbpause, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jbonlywatch, javax.swing.GroupLayout.DEFAULT_SIZE, 131, Short.MAX_VALUE)
                            .addComponent(jbport, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtsend, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jbsend, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(voice, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jbonlywatch, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(checkmouse)
                                    .addComponent(port, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jbport))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(checkkey)
                                    .addComponent(jbupload)
                                    .addComponent(jbpause)
                                    .addComponent(checkno))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel_permit)
                                .addGap(32, 32, 32)))
                        .addComponent(checkdos)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void checkmouseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkmouseActionPerformed
        // TODO add your handling code here:
        if (checkmouse.isSelected()) {
            if (!onlywatch) //投屏模式
            {
                cont.m(true);
            }
        } else {
            cont.m(false);
        }
    }//GEN-LAST:event_checkmouseActionPerformed

    private void voiceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voiceActionPerformed
        voice.setEnabled(false);
        try {
            new Info().Log("受控端于" + sdf.format(System.currentTimeMillis()) + " 结束语音通话。", stime, "op"); //日志记录
        } catch (IOException ex) {
        }
        sendToEveryClient("EndVoice!");
        c.off();
        s.off();

    }//GEN-LAST:event_voiceActionPerformed

    private void jbsendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbsendActionPerformed
        // TODO add your handling code here:


    }//GEN-LAST:event_jbsendActionPerformed

    boolean onlywatch; //投屏模式状态（观察者模式）
    private void jbonlywatchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbonlywatchActionPerformed
        if (jbonlywatch.getText().equals("投屏模式：关")) {
            onlywatch = true;
            checkmouse.setSelected(false);
            checkdos.setSelected(false);
            checkkey.setSelected(false); //停止DOS、鼠标、键盘事件
            cont.k(false);
            cont.m(false); //指令关闭
            this.setTitle(new Info().GetLocalIP() + " : 受控端 - 投屏模式");
            jbonlywatch.setText("投屏模式：开");
            try {
                new Info().Log("受控端于" + sdf.format(System.currentTimeMillis()) + " 启动了投屏模式。", stime, "op"); //日志记录
            } catch (IOException ex) {
            }
        } else {
            onlywatch = false;
            //键盘鼠标事件
            cont.k(checkkey.isSelected());
            cont.m(checkmouse.isSelected());
            //
            jbonlywatch.setText("投屏模式：关");
            this.setTitle(new Info().GetLocalIP() + " : 受控端");
            try {
                new Info().Log("受控端于" + sdf.format(System.currentTimeMillis()) + " 关闭了投屏模式。", stime, "op"); //日志记录
            } catch (IOException ex) {
            }
        }
    }//GEN-LAST:event_jbonlywatchActionPerformed

    private void checkkeyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkkeyActionPerformed
        if (checkkey.isSelected()) {
            if (!onlywatch) //投屏模式
            {
                cont.k(true);
            }
        } else {
            cont.k(false);
        }        // TODO add your handling code here:
    }//GEN-LAST:event_checkkeyActionPerformed

    private void jbpauseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbpauseActionPerformed

        if (jbpause.getText().equals("暂停连接")) {
            capt.state(false);
            checkkey.setSelected(false); //关闭键盘事件
            checkmouse.setSelected(false); //关闭鼠标事件
            checkdos.setSelected(false); //关闭DOS
            cont.k(false);
            cont.m(false); //指令关闭
            pausestate = true;
            jbpause.setText("继续连接");
            try {
                new Info().Log("受控端于" + sdf.format(System.currentTimeMillis()) + " 暂停了图像连接。", stime, "op"); //日志记录
            } catch (IOException ex) {
            }
        } else {
            capt.state(true);
            cont.k(checkkey.isSelected());
            cont.m(checkmouse.isSelected()); //指令判断
            jbpause.setText("暂停连接");
            pausestate = false;
            try {
                new Info().Log("受控端于" + sdf.format(System.currentTimeMillis()) + " 恢复了图像连接。", stime, "op"); //日志记录
            } catch (IOException ex) {
            }
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jbpauseActionPerformed

    private void jbuploadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbuploadActionPerformed
        JFileChooser djFileChooser = new JFileChooser();
        int approve = djFileChooser.showDialog(this, "选择上传文件..");
        if (approve == JFileChooser.APPROVE_OPTION) {        //判断是否点击了确定。如果是取消则无操作
            File dselectedFile = djFileChooser.getSelectedFile();
            String dpath = dselectedFile.getAbsolutePath();
            Thread tc = new Thread(new Runnable() {
                public void run() {
                    new FileClient().sendFile(clientIP, dport, dpath);
                }
            });
            tc.start();
        }
    }//GEN-LAST:event_jbuploadActionPerformed

    private void checkdosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkdosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_checkdosActionPerformed

    private void aboutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aboutActionPerformed
        JOptionPane.showMessageDialog(this, "简易局域网远程协助软件 v0.1"
                + "\n\n控制程序基于 Java TCP Socket\n语音通讯基于 Java UDP Socket\n界面设计基于 Java GUI Swing"
                + "\n本程序是自由软件(Free Software)"
                + "\n\n最后打印于: " + sdf.format(System.currentTimeMillis()),
                "关于程序", JOptionPane.PLAIN_MESSAGE);
    }//GEN-LAST:event_aboutActionPerformed

    private void linkstateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_linkstateActionPerformed

        JOptionPane.showMessageDialog(this,
                "程序支持多个控制端同时连接到单个受控端上"
                + "\n但至多一个控制端执行控制"
                + "\n至多进行一项语音通讯以及文件传输，通信功能不在此限制范围"
                + "\n若有多连接的需求，为了保证用户使用体验"
                + "\n受控端请开启投屏模式功能"
                + "\n\nSocket端口:"
                + "\n通信、图像传输及控制Socket端口 - 用户自定义"
                + "\n语音端口 8990-8993"
                + "\n受控端文件传输端口 12930"
                + "\n控制端文件传输端口 随机生成"
                + "\n\n程序会根据启动时间在程序目录自动生成对应的完整的日志信息"
                + "\n\n最后打印于: " + sdf.format(System.currentTimeMillis()),
                "Socket连接说明", JOptionPane.PLAIN_MESSAGE);
    }//GEN-LAST:event_linkstateActionPerformed

    private void logActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logActionPerformed

        String fileName = "日志文件\\";
        System.out.println(fileName);
        try {
            Runtime.getRuntime().exec("cmd /c start \"\" " + fileName);
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }        // TODO add your handling code here:

    }//GEN-LAST:event_logActionPerformed

    private void stateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stateActionPerformed
        JOptionPane.showMessageDialog(this,
                "启动时间： " + stime
                + "\n本机IP： " + new Info().GetLocalIP()
                + "\n主连接者IP： " + clientIP
                + "\n主连接者文件传输端口： " + dport
                + "\n当前控制端连接数： " + connectnum
                + "\n暂停连接状态： " + pausestate
                + "\n投屏模式状态： " + onlywatch
                + "\n\n最后打印于: " + sdf.format(System.currentTimeMillis()),
                "状态信息", JOptionPane.PLAIN_MESSAGE);
    }//GEN-LAST:event_stateActionPerformed

    private void checknoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checknoActionPerformed
        if (checkno.isSelected() == true) {
            checkmouse.setSelected(true);
            checkkey.setSelected(true);
            cont.m(true);
            cont.k(true);
            checkdos.setSelected(true);
            checkmouse.setEnabled(false);
            checkkey.setEnabled(false);
            checkdos.setEnabled(false);
        } else {
            checkmouse.setSelected(false);
            checkkey.setSelected(false);
            cont.m(false);
            cont.k(false);
            checkdos.setSelected(false);
            checkmouse.setEnabled(true);
            checkkey.setEnabled(true);
            checkdos.setEnabled(true);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_checknoActionPerformed

    public class FileClient {

        /**
         * 发送文件
         */
        public void sendFile(String ip, int port, String path) {
            File file = new File(path);
            try (
                    //创建连接，创建文件输入流，网络输出流
                    Socket socket = new Socket(ip, port);
                    InputStream in = new FileInputStream(path);
                    DataOutputStream out = new DataOutputStream(socket.getOutputStream())) {
                //先发送文件给服务器
                out.writeUTF(file.getName());
                out.flush();
                //读取本地文件，写入到网络输出流中
                int len = 0;
                byte[] buffer = new byte[1024];
                while ((len = in.read(buffer)) != -1) {
                    out.write(buffer, 0, len);
                }
                //System.out.println("客户端发送完毕！");
                try {
                    new Info().Log(" 文件" + path + " 于" + sdf.format(System.currentTimeMillis()) + " 上传至控制端。", stime, "op"); //日志记录
                } catch (IOException ex) {
                }
            } catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Main.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Main.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Main.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension dm = toolkit.getScreenSize();
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                Main f = new Main();
                f.setVisible(true);

                Toolkit kit = Toolkit.getDefaultToolkit();
                Dimension screen = kit.getScreenSize();         //获取屏幕大小
                f.setLocation((screen.width - f.getWidth()), (screen.height - f.getHeight() - 50)); //右下角显示

                f.setTitle(new Info().GetLocalIP() + " : 受控端");

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu Menu;
    private javax.swing.JMenuBar MenuBar;
    private javax.swing.JMenuItem about;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JCheckBox checkdos;
    private javax.swing.JCheckBox checkkey;
    private javax.swing.JCheckBox checkmouse;
    private javax.swing.JCheckBox checkno;
    private javax.swing.Box.Filler filler1;
    private javax.swing.JButton jButton1;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    private javax.swing.JLabel jLabel_permit;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JScrollPane jScrollPane;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JButton jbonlywatch;
    private javax.swing.JButton jbpause;
    private javax.swing.JButton jbport;
    private javax.swing.JButton jbsend;
    private javax.swing.JButton jbupload;
    private javax.swing.JTextField jtsend;
    private javax.swing.JTextArea jtshow;
    private javax.swing.JMenuItem linkstate;
    private javax.swing.JMenuItem log;
    private javax.swing.JTextField port;
    private javax.swing.JMenuItem state;
    private javax.swing.JButton voice;
    // End of variables declaration//GEN-END:variables
}
