package Controlled;

import java.awt.AWTException;
import java.awt.Event;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.io.ObjectInputStream;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;

public class ControlThread extends Thread {

    private ObjectInputStream ois;
    private Robot robot;
    private boolean kpermit = false; //键盘事件(初始时不允许操作)
    private boolean mpermit = false; //鼠标事件(初始时不允许操作)
    private String stime;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");  //日期格式

    public ControlThread(ObjectInputStream ois, String stime) {
        this.ois = ois;
        this.stime = stime; //记录日志作用
    }

    @Override
    public void run() {
        try {
            robot = new Robot();
        } catch (AWTException e) {
        }
        while (true) {
            try {
                Object event = ois.readObject();
                InputEvent e = (InputEvent) event;
                actionEvent(e);
            } catch (Exception e) {
                //U.debug("ControlThread over!");
                return;
            }
        }
    }

    void k(boolean s) {
        kpermit = s;
    }

    void m(boolean s) {
        mpermit = s;
    }

    private void actionEvent(InputEvent e) throws Exception {

        if (kpermit == true) { //键盘事件,无效但保留。（未序列化问题 NotSerializionException）

            if (e instanceof java.awt.event.KeyEvent) {
                KeyEvent ke = (KeyEvent) e;
                int type = ke.getID();
                if (type == java.awt.Event.KEY_PRESS) {
                    robot.keyPress(ke.getKeyCode());
                }
                if (type == java.awt.Event.KEY_RELEASE) {
                    robot.keyRelease(ke.getKeyCode());
                }

            }
        }

        if (mpermit == true) { //鼠标事件
            if (e instanceof java.awt.event.MouseEvent) {
                MouseEvent me = (MouseEvent) e;
                int type = e.getID();
                if (type == java.awt.Event.MOUSE_DOWN) {
                    robot.mousePress(getMouseClick(me.getButton()));
                    new Info().Log("控制端在 " + sdf.format(System.currentTimeMillis()) + " 进行了鼠标操作。[" + me.toString() + "]\n", stime,"op");
                } else if (type == java.awt.Event.MOUSE_UP) {
                    robot.mouseRelease(getMouseClick(me.getButton()));
                    new Info().Log("控制端在 " + sdf.format(System.currentTimeMillis()) + " 进行了鼠标操作。[" + me.toString() + "]\n", stime,"op");
                } else if (type == java.awt.Event.MOUSE_MOVE) {
                    robot.mouseMove(me.getX(), me.getY());
                } else if (type == Event.MOUSE_DRAG) {
                    robot.mouseMove(me.getX(), me.getY());
                }

            }
        } else {
        }
    }

    private int getMouseClick(int button) {
        if (button == MouseEvent.BUTTON1) {
            System.out.println("鼠标左键被按下");
            return InputEvent.BUTTON1_MASK;
        }
        if (button == MouseEvent.BUTTON2) {
            System.out.println("鼠标中键被按下");
            return InputEvent.BUTTON2_MASK;
        }
        if (button == MouseEvent.BUTTON3) {
            System.out.println("鼠标右键被按下");
            return InputEvent.BUTTON3_MASK;
        }
        return -1;
    }
}
