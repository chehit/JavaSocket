package Controlled;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;


import java.io.File;
import javax.imageio.ImageIO;

public class CaptureThread extends Thread {

    public static final int DPS = 20;
    public static final int THREAD_NUM = 5;
    private DataOutputStream dos;
    private Robot robot;//robot
    private boolean permit=true;
    public CaptureThread(DataOutputStream dos) {
        this.dos = dos;
    }
    
    void state(boolean s){
    permit=s;
    }

    @Override
    public void run() {
        try {
            robot = new Robot();
        } catch (AWTException e1) {
            e1.printStackTrace();
        }
        final Toolkit tk = java.awt.Toolkit.getDefaultToolkit();
        final Dimension dm = tk.getScreenSize();
        final Rectangle rec = new Rectangle(dm);
        try {
            dos.writeDouble(dm.getHeight());
            dos.writeDouble(dm.getWidth());
            dos.flush();
        } catch (IOException e1) {
            
            return;
        }
        while(true){
            try {
                long begin = System.currentTimeMillis();
                byte[] data = createImage(rec);
                if (permit==true){ //是否允许传输判断
                dos.writeInt(data.length);
                dos.write(data);
                dos.flush();
                }
                
                long end = System.currentTimeMillis();
                if ((end - begin) < 1000 / DPS) {
                    Thread.sleep(1000 / DPS - (end - begin));
                }
                
            } catch (Exception e) {
                return;
            }
        }
    }

    @SuppressWarnings("restriction")
    private byte[] createImage(Rectangle rec) throws IOException {
        BufferedImage bufImage = robot.createScreenCapture(rec);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
//        JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(baos);
//        encoder.encode(bufImage);

        ImageIO.write(bufImage, /*"GIF"*/ "jpg" /* format desired */,baos /* target */);

        return baos.toByteArray();
    }
}
