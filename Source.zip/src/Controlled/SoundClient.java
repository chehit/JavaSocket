package Controlled;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.TargetDataLine;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
public class SoundClient extends Thread {

    String IP;
    int Port;
    DatagramSocket socket;
    TargetDataLine line;
    public SoundClient() {

    }

    public SoundClient(int port, String ip) {
        IP = ip;
        Port = port;
    }

    
    public void off(){
            socket.close();
    socket.disconnect();

   // line.close();
    }
    public void run() {
        AudioFormat format = new AudioFormat(8000, 16, 2, true, true);
        
        
        DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
        if (!AudioSystem.isLineSupported(info)) {
            System.out.println("Not Supported");
            System.exit(1);
        }
        try {
            socket = new DatagramSocket(8992);
            InetAddress IPAddress = InetAddress.getByName(IP);
            line = (TargetDataLine) AudioSystem.getLine(info);
            line.open(format);
            int numBytesRead;
            byte[] data = new byte[line.getBufferSize() / 5];
            int totalBytesRead = 0;
            line.start();
            while (true) {
                numBytesRead = line.read(data, 0, data.length);
                DatagramPacket sendPacket = new DatagramPacket(data, data.length, IPAddress, Port);
                socket.send(sendPacket);
            }

        } catch (LineUnavailableException e) {
            e.printStackTrace();
        } catch (SocketException ex) {
            Logger.getLogger(SoundClient.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnknownHostException ex) {
            Logger.getLogger(SoundClient.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(SoundClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
