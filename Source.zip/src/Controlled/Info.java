package Controlled;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;

public class Info {

    public String GetLocalIP() {
        Process process;
        try {
            process = Runtime.getRuntime().exec("cmd.exe /c \"@Echo off&for /f \"tokens=4\" %a in ('route print^|findstr 0.0.0.0.*0.0.0.0') do (echo.%a)\""); //DOS命令取IP
            InputStreamReader r = new InputStreamReader(process.getInputStream(), "UTF-8");
            LineNumberReader returnData = new LineNumberReader(r);
            String returnMsg = "";
            String line = "";
            while ((line = returnData.readLine()) != null) {
                System.out.println(line);
                return line; //取第一行获得的IP值
                //System.out.println(returnData.getLineNumber()+" "+line);
                //returnMsg += line;
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    //日志记录(简易)
    public void Log(String str, String time, String mode) throws IOException {
        String ftime = time.replace(":", "-"); //文件名不允许出现" : "
        File file1 = new File("日志文件\\" + ftime); //创建一个日志文件夹
        if (!file1.exists()) {
            file1.mkdirs();
        }
        if (mode.equals("op")) { //操作事件

            FileWriter writer;
            try {
                writer = new FileWriter("日志文件/" + ftime + "/操作日志.log", true);
                writer.write(str + "\r\n"); // \r\n才能换行
                writer.flush();
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

        if (mode.equals("chat")) { //聊天记录事件
            FileWriter writer;
            try {
                writer = new FileWriter("日志文件/" + ftime + "/通信记录.log", true);
                writer.write(str + "\r\n"); // \r\n才能换行
                writer.flush();
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

    }

}
