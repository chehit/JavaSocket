package Console;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author YinTM
 */
public class SoundServer extends Thread {

    DatagramSocket socket;
    SourceDataLine speakers;

    public SoundServer(DatagramSocket s) {
        socket = s;
    }

    public void off() {
        socket.close();
        socket.disconnect();

        //speakers.close();
    }

    public void run() {
        AudioFormat format = new AudioFormat(8000, 16, 2, true, true);

        DataLine.Info dataLineInfo = new DataLine.Info(SourceDataLine.class, format);
        try {
            speakers = (SourceDataLine) AudioSystem.getLine(dataLineInfo);
            speakers.open(format);
            //DatagramSocket socket;
            //socket = new DatagramSocket(8080);
            byte[] data = new byte[speakers.getBufferSize() / 5];
            speakers.start();
            while (true) {

                DatagramPacket receivePacket = new DatagramPacket(data, data.length);
                socket.receive(receivePacket);
                speakers.write(data, 0, data.length);
            }
        } catch (LineUnavailableException ex) {
            Logger.getLogger(SoundServer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SocketException ex) {
            Logger.getLogger(SoundServer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(SoundServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
