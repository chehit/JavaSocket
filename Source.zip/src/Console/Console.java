package Console;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.BindException;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.stage.DirectoryChooser;
import javax.imageio.ImageIO;
import javax.imageio.stream.ImageOutputStream;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.text.Caret;

/**
 *
 * @author Ctr1
 */
public class Console extends javax.swing.JFrame {

    protected String verification = ".&/.&/././/-+_+Connection!Connection!HHH###This is the special mark of this program###HHH/./.{verification}{{[[true&&pass]]}}";
    JFrame dosframe;
    Socket cli; //语音通话Socket
    DatagramSocket voicesocket = null;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  //日期格式
    
    /**
     * Creates new form NewJFrame
     */
    public Console() {
        initComponents();
        init();

    }

    public class FileServer {

        public static final int PORT = 12930; //download端口
        int port;

        FileServer(int p) {
            port = p; //端口
            System.out.println("文件上传端口：" + port);
        }

        public void start() {
            System.out.println("start...");
            String dpath = null;
            try ( //创建服务器端对象
                    ServerSocket server = new ServerSocket(port);) {
                while (true) {
                    Socket socket = server.accept();
                    int option = JOptionPane.showConfirmDialog(Console.this, "接收到文件，是否同意接收？", "提示", JOptionPane.YES_OPTION); //Server.this 设定父窗口
                    if (option == JOptionPane.YES_OPTION) {
                        JFileChooser Chooser = new JFileChooser();
                        Chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

                        int approve = Chooser.showDialog(Console.this, "选择目录");
                        if (approve == JFileChooser.APPROVE_OPTION) {        //判断是否点击了确定。如果是取消则无操作
                            File dselectedFile = Chooser.getSelectedFile();
                            dpath = dselectedFile.getAbsolutePath(); //目标保存目录
                            if (!dpath.equals("")) {
                                try ( //创建文件输出流和网络输入流
                                        DataInputStream in = new DataInputStream(socket.getInputStream());
                                        //读取发来的文件名**，创建文件输出流
                                        FileOutputStream out = new FileOutputStream(dpath + "\\" + in.readUTF())) { // FileOutputStream out = new FileOutputStream(dpath + in.readUTF())) {
                                    int len = 0;
                                    byte[] buffer = new byte[1024];
                                    while ((len = in.read(buffer)) != -1) {
                                        out.write(buffer, 0, len);
                                    }
                                    show.append("文件已经保存到 " + dpath + "\n");
                                    System.out.println("服务器保存完毕！");
                                }
                            }
                        }
                    } else {
                        //点了否，无操作

                    }
                }
            } catch (BindException e) {
                upload.setEnabled(false); //禁用上传文件
                upload.setToolTipText("无法启动文件上传端口");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    private BufferedReader reader;
    private PrintWriter writer;
    boolean voiceState; //语音连接状态
    SoundClient c;
    SoundServer s;

    private void init() {

        upload.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); //设置按钮小手
        dos.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        voice.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); //设置按钮小手

        Runnable incomingReader = new Runnable() {
            @Override
            public void run() {
                String message;
                try {
                    while ((message = reader.readLine()) != null) {
                        if (message.equals("EndVoice!")) { //语音事件
                            voicetip.setText("");
                            voiceState = false;
                            voice.setEnabled(false); //功能停用。
                            c.off();
                            s.off();

                        } else if (message.equals("VoicechatPositive")) {
                            Thread voice = new Thread(new Runnable() {
                                public void run() {
                                    try {

//                                        cli = new Socket(ip.getText(), 8990);
//                                        Capture cap = new Capture(cli);
//                                        cap.start();
                                        voicesocket = new DatagramSocket(8991);
                                        s = new SoundServer(voicesocket);
                                        s.start();
                                        c = new SoundClient(8990, ip.getText());
                                        c.start();
                                        voiceState = true;
                                        voicetip.setText("语音通话中..");
                                    } catch (Exception e) {
                                        show.append("无法连接到语音通信端口。端口被占用或无权限。\n");
                                        voiceState = false;
                                    }
                                }
                            });
                            voice.start();

                        } else {
                            show.append(message + "\n");
                        }

                    }
                } catch (SocketException e) {
                    try {
                        reader.close();
                    } catch (IOException ex) {
                        Logger.getLogger(Console.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    writer.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        };

        // 监听Connect按钮，实现服务器的连接
        ActionListener ConnectListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String aServerIP = ip.getText();
                String aServerPort = port.getText();
                if (aServerIP.equals("") || aServerPort.equals("")) {
                    show.append("填入的格式有误。\n");
                    System.out.println("错误");
                } else {
                    try {
                        @SuppressWarnings("resource")
                        Socket clientSocket = new Socket(aServerIP, Integer.parseInt(aServerPort));
                        reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream(), "UTF-8"));
                        writer = new PrintWriter(new OutputStreamWriter(clientSocket.getOutputStream(), "UTF-8"), true);
                        // writer.println(verification); //验证
                        // writer.flush();
                        int dport = new java.util.Random().nextInt(300) * new java.util.Random().nextInt(10); //文件随机传输port
                        Thread tc = new Thread(new Runnable() {
                            public void run() {
                                // run方法具体重写
                                new FileServer(dport).start();
                            }
                        });
                        tc.start(); //文件传送服务启动

                        writer.println("IP|%^^^#" + new Info().GetLocalIP() + "&" + dport); //本机IP加随机文件传输端口
                        writer.flush();

                        ImgUIThread ui = new ImgUIThread(aServerIP, Integer.parseInt(port.getText()), writer);
                        ui.start();
                        show.setText(""); //清空提示
                        show.append("主控端已连接...\n");
                        btEvent(); //连接事件
                        Thread readerThread = new Thread(incomingReader);
                        readerThread.start();
                    } catch (Exception ex) {
                        show.append("连接错误。\n");
                        System.out.println("错误");
                    }

                }
            }
        };
        port.addActionListener(ConnectListener); //添加连接端口监听器
        connect.addActionListener(ConnectListener);

        // 发送消息到服务器
        ActionListener SayListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String aText = jtsend.getText();
                String name;
                if (aText.equals("")) {
                    //  JOptionPane.showMessageDialog(clientFrame, "内容不能为空！");
                } else {
                    try {
                        if (Jname.getText().equals("")) {
                            name = "控制端";
                        } else {
                            name = Jname.getText();
                        }
                        writer.println(name + " : " + aText);
                        writer.flush();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                    jtsend.setText("");
                }
            }
        };
        jtsend.addActionListener(SayListener);
        send.addActionListener(SayListener);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        show = new javax.swing.JTextArea();
        jtsend = new javax.swing.JTextField();
        send = new javax.swing.JButton();
        upload = new javax.swing.JButton();
        dos = new javax.swing.JButton();
        voice = new javax.swing.JButton();
        ip = new javax.swing.JTextField();
        port = new javax.swing.JTextField();
        connect = new javax.swing.JButton();
        jSeparator = new javax.swing.JSeparator();
        Jname = new javax.swing.JTextField();
        jT_name = new javax.swing.JLabel();
        Watcher = new javax.swing.JButton();
        voicetip = new javax.swing.JLabel();
        MenuBar = new javax.swing.JMenuBar();
        Menu = new javax.swing.JMenu();
        linkstate = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("控制端");
        setAlwaysOnTop(true);
        setResizable(false);

        show.setEditable(false);
        show.setColumns(20);
        show.setFont(new java.awt.Font("宋体", 0, 15)); // NOI18N
        show.setRows(5);
        show.setText("请先连接到受控端。在下方输入框输入受控端的IP以及端口号。 \n");
        show.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jScrollPane1.setViewportView(show);

        jtsend.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jtsend.setEnabled(false);
        jtsend.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtsendActionPerformed(evt);
            }
        });

        send.setText("发送");

        upload.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Console/upload.png"))); // NOI18N
        upload.setToolTipText("上传文件");
        upload.setEnabled(false);
        upload.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uploadActionPerformed(evt);
            }
        });

        dos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Console/dos.png"))); // NOI18N
        dos.setToolTipText("打开DOS窗口");
        dos.setEnabled(false);
        dos.setMaximumSize(new java.awt.Dimension(131, 101));
        dos.setMinimumSize(new java.awt.Dimension(131, 101));
        dos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dosActionPerformed(evt);
            }
        });

        voice.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Console/voice.png"))); // NOI18N
        voice.setToolTipText("语音通话");
        voice.setEnabled(false);
        voice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voiceActionPerformed(evt);
            }
        });

        ip.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        port.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        connect.setText("连接");
        connect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                connectActionPerformed(evt);
            }
        });

        Jname.setText("控制端");
        Jname.setEnabled(false);

        jT_name.setText("客户端名称(可选)");

        Watcher.setText("观察者模式");
        Watcher.setToolTipText("观察者模式将只显示图像窗口");
        Watcher.setEnabled(false);
        Watcher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WatcherActionPerformed(evt);
            }
        });

        voicetip.setFont(new java.awt.Font("宋体", 1, 15)); // NOI18N

        Menu.setText("信息");

        linkstate.setText("连接说明");
        linkstate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                linkstateActionPerformed(evt);
            }
        });
        Menu.add(linkstate);

        jMenuItem1.setText("关于");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        Menu.add(jMenuItem1);

        MenuBar.add(Menu);

        setJMenuBar(MenuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(ip, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(port, javax.swing.GroupLayout.DEFAULT_SIZE, 119, Short.MAX_VALUE))
                            .addComponent(jtsend, javax.swing.GroupLayout.Alignment.LEADING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(send, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(connect, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(upload, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(dos, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(voice, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jT_name, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(voicetip, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Jname)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(Watcher)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ip)
                    .addComponent(port)
                    .addComponent(connect, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtsend, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(send, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(dos, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(voice, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(upload, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jT_name)
                            .addComponent(Jname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(Watcher, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(voicetip, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jtsendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtsendActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtsendActionPerformed

    private void connectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_connectActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_connectActionPerformed

    private void WatcherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WatcherActionPerformed
        this.setVisible(false);
        writer.println("**watcher**@#@#@#@#@#@#@#@#!!!!!");//请求停止键盘鼠标事件。以指令方式传递参。
        writer.flush();
    }//GEN-LAST:event_WatcherActionPerformed

    JTextField sends;
    private void dosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dosActionPerformed
        dosframe = new JFrame();
        dosframe.setVisible(true);
        dosframe.setBounds(500, 500, 500, 90);
        dosframe.setResizable(false);
        dosframe.setTitle("执行DOS指令 - Enter 执行");
        dosframe.setAlwaysOnTop(true);
        Toolkit kit = Toolkit.getDefaultToolkit();
        Dimension screen = kit.getScreenSize();         //获取屏幕大小
        dosframe.setLocation(10, (screen.height - dosframe.getHeight() - 50)); //左下角显示
        Font font = new Font("微软雅黑", Font.BOLD, 18);
        sends = new JTextField();
        sends.setForeground(Color.white);
        sends.setBackground(Color.black);
        sends.setFont(font);
        sends.setCaretColor(Color.white);
        dosframe.add(sends);
        ActionListener DosListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String Text = sends.getText();
                if (Text.equals("")) {
                    //  JOptionPane.showMessageDialog(clientFrame, "内容不能为空！");
                } else if (Text.equalsIgnoreCase("about")) {
                    JOptionPane.showMessageDialog(dosframe, "向受控端发送一行CMD指令。指令只支持可在CMD窗口运行的单行指令。\n特别地，cls 将会清空本程序的文本框内的所有内容。\n执行指令前必须拥有权限。\n指令只会被发送，是否被成功执行取决于受控端实际执行情况。", "提示", JOptionPane.PLAIN_MESSAGE);
                    sends.setText(null);
                } else if (Text.equalsIgnoreCase("cls")) { //CLS
                    show.setText("");
                    sends.setText(null);
                } else {
                    writer.println("dosEvent!" + Text);
                    writer.flush();
                    sends.setText(null); //置空

                }
            }
        };
        sends.addActionListener(DosListener);
        System.out.println("DOS事件");
    }//GEN-LAST:event_dosActionPerformed

    private void uploadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uploadActionPerformed
        JFileChooser djFileChooser = new JFileChooser();
        int approve = djFileChooser.showDialog(this, "选择上传文件..");
        if (approve == JFileChooser.APPROVE_OPTION) {        //判断是否点击了确定。如果是取消则无操作
            File dselectedFile = djFileChooser.getSelectedFile();
            String dpath = dselectedFile.getAbsolutePath();
            Thread tc = new Thread(new Runnable() {
                public void run() {
                    new FileClient().sendFile(ip.getText(), 12930, dpath);
                }
            });
            tc.start();
        }
    }//GEN-LAST:event_uploadActionPerformed

    private void voiceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voiceActionPerformed
        if (voiceState == false) {
            show.append("正在申请语音通信。\n");
            writer.println("VoiceChat!!!!!!");
            writer.flush();
        } else {

            c.off();
            s.off();
            this.setTitle("控制端");
            voicetip.setText("");
            voiceState = false;
            voice.setEnabled(false);
            writer.println("EndVoice!");
            writer.flush();

        }
//        try {
//            Socket cli = new Socket("127.0.0.1", 6000);
//            Capture cap = new Capture(cli);
//            cap.start();
//        } catch (Exception e) {
//        }
    }//GEN-LAST:event_voiceActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        JOptionPane.showMessageDialog(this, "简易局域网远程协助软件 v0.1"
                + "\n\n控制程序基于 Java TCP Socket\n语音通讯基于 Java UDP Socket\n界面设计基于 Java GUI Swing"
                + "\n本程序是自由软件(Free Software)"
                + "\n\n最后打印于: " + sdf.format(System.currentTimeMillis()),
                "关于程序", JOptionPane.PLAIN_MESSAGE); 
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void linkstateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_linkstateActionPerformed
        JOptionPane.showMessageDialog(this,
                "程序支持多个控制端同时连接到单个受控端上"
                + "\n但至多一个控制端执行控制"
                + "\n至多进行一项语音通讯以及文件传输，通信功能不在此限制范围"
                + "\n若有多连接的需求，为了保证用户使用体验"
                + "\n受控端请开启投屏模式功能"
                + "\n\nSocket端口:"
                + "\n通信、图像传输及控制Socket端口 - 用户自定义"
                + "\n语音端口 8990-8993"
                + "\n受控端文件传输端口 12930"
                + "\n控制端文件传输端口 随机生成"
                + "\n\n程序会根据启动时间在程序目录自动生成对应的完整的日志信息"
                + "\n\n最后打印于: " + sdf.format(System.currentTimeMillis()),
                "Socket连接说明", JOptionPane.PLAIN_MESSAGE);
    }//GEN-LAST:event_linkstateActionPerformed

    public void btEvent() {  //界面组件解锁
        connect.setEnabled(false);
        ip.setEnabled(false);
        port.setEnabled(false);
        Watcher.setEnabled(true);
        Jname.setEnabled(true);
        voice.setEnabled(true);
        dos.setEnabled(true);
        upload.setEnabled(true);
        send.setEnabled(true);
        jtsend.setEnabled(true);
    }

    public class FileClient {

        /**
         * 发送文件
         */
        public void sendFile(String ip, int port, String path) {
            File file = new File(path);
            try (
                    //创建连接，创建文件输入流，网络输出流
                    Socket socket = new Socket(ip, port);
                    InputStream in = new FileInputStream(path);
                    DataOutputStream out = new DataOutputStream(socket.getOutputStream())) {
                //先发送文件给服务器
                out.writeUTF(file.getName());
                out.flush();
                //读取本地文件，写入到网络输出流中
                int len = 0;
                byte[] buffer = new byte[1024];
                while ((len = in.read(buffer)) != -1) {
                    out.write(buffer, 0, len);
                }
                //System.out.println("客户端发送完毕！");
            } catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Console.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Console.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Console.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Console.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        System.setProperty("sun.java2d.uiScale", "1.0");
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Console f = new Console();
                f.setVisible(true);
                Toolkit kit = Toolkit.getDefaultToolkit();
                Dimension screen = kit.getScreenSize();         //获取屏幕大小
                f.setLocation((screen.width - f.getWidth()), (screen.height - f.getHeight() - 50)); //右下角显示

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Jname;
    private javax.swing.JMenu Menu;
    private javax.swing.JMenuBar MenuBar;
    private javax.swing.JButton Watcher;
    private javax.swing.JButton connect;
    private javax.swing.JButton dos;
    private javax.swing.JTextField ip;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator;
    private javax.swing.JLabel jT_name;
    private javax.swing.JTextField jtsend;
    private javax.swing.JMenuItem linkstate;
    private javax.swing.JTextField port;
    private javax.swing.JButton send;
    private javax.swing.JTextArea show;
    private javax.swing.JButton upload;
    private javax.swing.JButton voice;
    private javax.swing.JLabel voicetip;
    // End of variables declaration//GEN-END:variables
}
